$(document).ready(function () {

    var navigation = $('.navbar-static-top');
    var origOffsetY = navigation.offset().top;

    function scroll() {
        if ($(window).scrollTop() >= origOffsetY) {
            $('.navbar-static-top').addClass('fixed-top');
        } else {
            $('.navbar-static-top').removeClass('fixed-top');
        }


    }

    document.onscroll = scroll;

});

$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').focus()
})



